<?php
$purechatHome = 'https://app.purechat.com';
?>